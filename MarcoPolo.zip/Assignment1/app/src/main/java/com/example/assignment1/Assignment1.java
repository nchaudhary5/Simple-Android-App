// Nabin Chaudhary
// NedId: ad4859
// Assignment1

package com.example.assignment1;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import android.widget.Button;
import android.widget.Toast;

public class Assignment1 extends AppCompatActivity {
    private Button mTrueButton, mFalseButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignment1);

        mTrueButton = (Button)findViewById(R.id.true_button);
        mFalseButton = (Button)findViewById(R.id.false_button);

        // True Button Listener
        mTrueButton.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Code to execute on button click goes here.
                Toast.makeText(Assignment1.this,
                        R.string.correct_toast,
                        Toast.LENGTH_SHORT).show();
            }
        });

        //False Button Listener
        mFalseButton.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Code to execute on button click goes here.
                Toast.makeText(Assignment1.this,
                        R.string.incorrect_toast,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
